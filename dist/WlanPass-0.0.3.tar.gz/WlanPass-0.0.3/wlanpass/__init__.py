from wlanpass import getwifipass
